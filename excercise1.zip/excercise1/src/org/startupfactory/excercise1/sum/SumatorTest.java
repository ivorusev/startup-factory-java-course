/**
 * 
 */
package org.startupfactory.excercise1.sum;

import org.junit.Assert;
import org.junit.Test;

/**
 * Tests the sumator.
 * 
 * @author Ivo
 *
 */
public class SumatorTest {

	@Test
	public void testSummingOfIntegers() {
		int result = Sumator.sum(2, 2);
		Assert.assertEquals(4, result);
	}

	@Test
	public void testSummingOfFloats() {
		float a = 2.0f;
		float b = 2.0f;
		float result = Sumator.sum(a, b);
		Assert.assertEquals(a + b, result, 0.1);
	}

}
