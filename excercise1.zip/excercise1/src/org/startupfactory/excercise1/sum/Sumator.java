/**
 * 
 */
package org.startupfactory.excercise1.sum;

/**
 * A class that has methods for summing ints and floats.
 * 
 * @author Ivo
 *
 */
public class Sumator {

	/**
	 * Sums two integers.
	 * 
	 * @param firstNumber
	 *            the first number
	 * @param secondNumber
	 *            the second number.
	 * @return the sum of the two parameters
	 */
	public static int sum(int firstNumber, int secondNumber) {
		return firstNumber + secondNumber;
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static float sum(float a, float b) {
		return a + b;
	}

}
