package org.startupfactory.excercise1.fizzbuzz;

/**
 * 
 * @author vsr
 *
 */
public class FizzBuzz {

	/**
	 * 
	 * @param n
	 * @return
	 */
	public static String getFirstN(int n) {
		StringBuilder result = new StringBuilder();
		for (int i = 1; i <= n; i++) {
			if ((i % 3 == 0) && (i % 5 == 0)) {
				result.append("Fizz Buzz");
			} else if (i % 5 == 0) {
				result.append("Buzz");
			} else if (i % 3 == 0) {
				result.append("Fizz");
			} else {
				result.append(i);
			}

			if (i < n) {
				result.append(", ");
			}
		}

		return result.toString();
	}

}
