/**
 * 
 */
package org.startupfactory.excercise1.fizzbuzz;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author vsr
 *
 */
public class FizzBuzzTest {

	@Test
	public void testFirst15() {
		String expected = "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz, 11, Fizz, 13, 14, Fizz Buzz";
		String result = FizzBuzz.getFirstN(15);
		Assert.assertEquals(expected, result);
	}

	@Test
	public void testFirst3() {
		String expected = "1, 2, Fizz";
		String result = FizzBuzz.getFirstN(3);
		Assert.assertEquals(expected, result);
	}

	@Test
	public void test0() {
		String expected = "";
		String result = FizzBuzz.getFirstN(0);
		Assert.assertEquals(expected, result);
	}

}
