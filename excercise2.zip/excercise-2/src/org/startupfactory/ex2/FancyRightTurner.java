package org.startupfactory.ex2;

public class FancyRightTurner extends RightTurner {

	public FancyRightTurner(int street, int avenue, Direction direction, int beepers) {
		super(street, avenue, direction, beepers);
	}

	@Override
	public void turnRight() {
		for (int i = 0; i < 7; i++) {
			turnLeft();
		}
	}

}
