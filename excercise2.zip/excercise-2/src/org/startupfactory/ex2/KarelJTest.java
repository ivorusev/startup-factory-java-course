package org.startupfactory.ex2;

import kareltherobot.Directions;
import kareltherobot.World;

public class KarelJTest {

	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setDelay(50);
		World.setVisible(true);

		FancyRightTurner robot = new FancyRightTurner(2, 2, Directions.North, 10);
		robot.setVisible(true);

		robot.turnRight();
	}

}
