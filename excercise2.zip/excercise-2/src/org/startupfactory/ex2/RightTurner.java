package org.startupfactory.ex2;

import kareltherobot.Robot;

public class RightTurner extends Robot {

	/**
	 * Inherited Constructor
	 * 
	 * @param street
	 * @param avenue
	 * @param direction
	 * @param beepers
	 */
	public RightTurner(int street, int avenue, Direction direction, int beepers) {
		super(street, avenue, direction, beepers);
	}

	/**
	 * Turns the robot right.
	 */
	public void turnRight() {
		turnLeft();
		turnLeft();
		turnLeft();
	}
}
