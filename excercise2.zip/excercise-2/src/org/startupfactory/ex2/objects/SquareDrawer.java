/**
 * 
 */
package org.startupfactory.ex2.objects;

import org.startupfactory.ex2.RightTurner;

import kareltherobot.Directions;

/**
 * @author vsr
 *
 */
public class SquareDrawer extends RightTurner implements Drawer {

	public SquareDrawer(int street, int avenue, int beepers) {
		super(street, avenue, Directions.North, beepers);
		setVisible(true);
	}

	@Override
	public void draw(Figure figure) {
		Square square = (Square) figure;

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < square.getSide(); j++) {
				putBeeper();
				move();
			}
			turnRight();
		}

	}

}
