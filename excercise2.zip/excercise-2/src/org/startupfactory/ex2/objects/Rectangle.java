/**
 * 
 */
package org.startupfactory.ex2.objects;

/**
 * @author vsr
 *
 */
public class Rectangle extends Square {

	private int side2;

	public Rectangle(int x, int y, int side, int side2) {
		super(x, y, side);
		this.setSide2(side);
	}

	@Override
	public String toString() {
		return super.toString() + " side2: " + side2;

	}

	public int getSide2() {
		return side2;
	}

	public void setSide2(int side2) {
		this.side2 = side2;
	}

}
