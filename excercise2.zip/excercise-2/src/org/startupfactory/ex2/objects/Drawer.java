package org.startupfactory.ex2.objects;

public interface Drawer {

	void draw(Figure figure);

}
