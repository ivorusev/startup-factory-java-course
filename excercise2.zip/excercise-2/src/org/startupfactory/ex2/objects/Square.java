/**
 * 
 */
package org.startupfactory.ex2.objects;

/**
 * @author vsr
 *
 */
public class Square extends Figure {

	private int x;
	private int y;
	private int side;

	public Square(int x, int y, int side) {
		this.x = x;
		this.y = y;
		this.side = side;
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		if (x < 1) {
			throw new IllegalArgumentException();
		}
		this.x = x;
	}

	@Override
	public String toString() {
		return "x: " + x + " y: " + y + " side: " + side;
	}

}
