/**
 * 
 */
package org.startupfactory.ex2.objects;

import kareltherobot.World;

/**
 * @author vsr
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setVisible(true);
		World.setDelay(30);
		// TODO Auto-generated method stub
		Square square = new Square(1, 1, 3);
		System.out.println(square);

		Drawer drawer = new SquareDrawer(1, 1, 100);
		drawer.draw(square);
		// Drawer drawer2 = new RectangleDrawer(1, 1, 100);
	}

}
