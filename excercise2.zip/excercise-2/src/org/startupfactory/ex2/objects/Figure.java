/**
 * 
 */
package org.startupfactory.ex2.objects;

/**
 * @author vsr
 *
 */
public abstract class Figure {

}
