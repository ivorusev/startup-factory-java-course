/**
 * 
 */
package org.startupfactory.ex2.objects;

import kareltherobot.Directions;
import kareltherobot.Robot;

/**
 * @author vsr
 *
 */
public class RectangleDrawer extends Robot implements Drawer {

	public RectangleDrawer(int street, int avenue, int beepers) {
		super(street, avenue, Directions.North, beepers);
	}

	@Override
	public void draw(Figure figure) {
		// TODO Auto-generated method stub
	}

}
