package org.startupfactory.ex2.tests;

import org.junit.Test;
import org.startupfactory.ex2.RightTurner;

import kareltherobot.Directions;
import kareltherobot.KJRTest;
import kareltherobot.World;

public class RightTurnerRobotTest extends KJRTest {

	public RightTurnerRobotTest(String name) {
		super(name);
	}

	@Test
	public void test() {
		World.setSize(1, 1);
		World.setDelay(1);
		RightTurner robot = new RightTurner(1, 1, Directions.North, 10);
		robot.turnRight();
		assertAt(robot, 1, 1);
		assertFacingEast(robot);
	}

}
