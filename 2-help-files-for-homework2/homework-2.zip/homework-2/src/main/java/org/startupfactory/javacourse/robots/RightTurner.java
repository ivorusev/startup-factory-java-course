package org.startupfactory.javacourse.robots;

import kareltherobot.Robot;

/**
 * TODO: Document!
 */
public class RightTurner extends Robot {

	/**
	 * TODO: Document!
	 */
	public RightTurner(int street, int avenue, Direction direction) {
		super(street, avenue, direction, Integer.MAX_VALUE);
		setVisible(true);
	}

	/**
	 * TODO: Document!
	 */
	public void turnRight() {
		// TODO: implement
	}

}
