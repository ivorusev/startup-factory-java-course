package annotations;

@Order
public class MediumBrick extends AbstractBrick {

	@Override
	public String toString() {
		return "This is a medium brick";
	}
}
