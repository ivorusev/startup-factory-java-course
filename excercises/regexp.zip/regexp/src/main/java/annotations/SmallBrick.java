package annotations;

@Order(value = 0)
public class SmallBrick extends AbstractBrick {
	
	@Override
	public String toString() {
		return "This is a small brick";
	}

}
