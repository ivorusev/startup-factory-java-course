package annotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Runner {
	
	public static void main(String[] args) {
		AbstractBrick big = new BigBrick();
		AbstractBrick small = new SmallBrick();
		AbstractBrick medium = new MediumBrick();
		
		List<AbstractBrick> asList = Arrays.asList(big, small, medium);
		Collections.sort(asList);
		System.out.println(asList);
	}

}
