package annotations;

@Order
public class AbstractBrick implements Comparable<AbstractBrick> {

	public int compareTo(AbstractBrick o) {
		int value1 = o.getClass().getAnnotation(Order.class).value();
		int value2 = this.getClass().getAnnotation(Order.class).value();
		
		return value1 - value2;
	}

}
