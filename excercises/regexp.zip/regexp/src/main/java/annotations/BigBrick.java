package annotations;

@Order(value = 5)
public class BigBrick extends AbstractBrick{
	
	@Override
	public String toString() {
		return "This is a big brick";
	}
}
