/**
 * 
 */
package regexp;

/**
 * @author irusev
 *
 */
public class RegExpTester {
	
	public static void main(String[] args) {
		ValidateLetters.printResult(".rusev.i@gmail.com ggg abcdef test 1010101010");
	}

}
