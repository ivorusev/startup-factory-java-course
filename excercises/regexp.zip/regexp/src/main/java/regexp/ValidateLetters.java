/**
 * 
 */
package regexp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author irusev
 *
 */
public class ValidateLetters {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateLetters.class);

	private static final String LETTERS = "[a-z]{1}[[a-z0-9]\\._-]{3,20}@gmail\\.com";

	private static final Pattern PATTERN = Pattern.compile(LETTERS);

	public static void printResult(final String input) {
		Matcher matcher = PATTERN.matcher(input);
		while (matcher.find()) {
			LOGGER.info("Found: {}, starting at index {}, and ending at index {}", matcher.group(), matcher.start(),
					matcher.end());
		}
	}

}
