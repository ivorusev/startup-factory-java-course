package org.startupfactory.javacourse.io.consoledemo;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ConsoleReaderTest {

	private static final String EXPECTED = "one line";

	@Before
	public void init() {
		String input = "one line" + System.lineSeparator();
		ByteArrayInputStream inputMock = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
		System.setIn(inputMock);
	}

	@Test
	public void testReadLineWithScanner() {
		String actual = ConsoleReader.readLine();
		Assert.assertEquals(EXPECTED, actual);
	}

	@Test
	public void testReadLineWithInputStream() {
		String actual = ConsoleReader.readLineFromIS();
		Assert.assertEquals(EXPECTED, actual);
	}

	@Test
	public void testReadLineWithReader() {
		String actual = ConsoleReader.readLineWithReader();
		Assert.assertEquals(EXPECTED, actual);
	}

}
