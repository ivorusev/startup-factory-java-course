/**
 * 
 */
package org.startupfactory.javacourse.io.consoledemo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * @author vsr
 *
 */
public class ConsoleReader {

	/**
	 * Reads one line from the console.
	 * 
	 * @return the input as a String
	 */
	public static String readLine() {
		String result = null;
		try (Scanner scanner = new Scanner(System.in)) {
			result = scanner.nextLine();
			scanner.close();
		}
		return result;
	}

	public static String readLineFromIS() {
		InputStream ins = null;
		try {
			StringBuilder line = new StringBuilder();
			ins = new BufferedInputStream(System.in);

			int result = -1;
			while ((result = ins.read()) != 13) {
				char letter = (char) result;
				line.append(letter);
			}

			return line.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ins != null) {
					ins.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * 
	 * @return
	 */
	public static String readLineWithReader() {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			return reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
