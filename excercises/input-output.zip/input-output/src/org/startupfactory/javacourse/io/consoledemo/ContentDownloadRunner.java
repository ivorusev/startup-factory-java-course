/**
 * 
 */
package org.startupfactory.javacourse.io.consoledemo;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author vsr
 *
 */
public class ContentDownloadRunner {

	/**
	 * @param args
	 * @throws MalformedURLException
	 */
	public static void main(String[] args) throws MalformedURLException {
		URL url = new URL("https://www.google.bg/");
		final String result = ContentDownloader.download(url);
		System.out.println(result);

		URL fileurl = new URL("https://www.adobe.com/enterprise/accessibility/pdfs/acro6_pg_ue.pdf");
		File file = new File("D:\\out.pdf");
		ContentDownloader.downloadInFile(fileurl, file);

		File validFile = new File("D:\\valid.txt");
		ContentDownloader.downloadFile(url, validFile);
	}

}
