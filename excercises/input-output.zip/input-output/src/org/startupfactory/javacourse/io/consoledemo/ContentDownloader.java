/**
 * 
 */
package org.startupfactory.javacourse.io.consoledemo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * @author vsr
 *
 */
public class ContentDownloader {

	public static String download(URL url) {
		StringBuilder result = new StringBuilder();
		try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {
			while (in.ready()) {
				String oneLine = in.readLine();
				result.append(oneLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static void downloadInFile(URL url, File file) {
		StringBuilder result = new StringBuilder();
		try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {
			while (in.ready()) {
				String oneLine = in.readLine();
				result.append(oneLine);
			}

			try (OutputStream out = new FileOutputStream(file)) {
				out.write(result.toString().getBytes(StandardCharsets.UTF_8));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void downloadFile(URL url, File file) {
		InputStream ins = null;
		OutputStream out = null;
		try {
			out = new FileOutputStream(file);
			ins = new BufferedInputStream(url.openStream());
			byte[] buffer = new byte[1024];

			int bytesRead = 0;
			while ((bytesRead = ins.read(buffer, 0, 1024)) != -1) {
				out.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ins != null) {
					ins.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

}
