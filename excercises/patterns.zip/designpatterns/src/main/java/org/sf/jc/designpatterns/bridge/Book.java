package org.sf.jc.designpatterns.bridge;

public class Book extends Manuscript {

	public Book(MyFormatter formatter) {
		super(formatter);
	}
	
	public Book(MyFormatter formatter, String publisher, int year) {
		super(formatter);
		this.publisherName = publisher;
		this.year = year;		
	}

	private String publisherName;
	private int year;

	@Override
	void printInformation() {
		String info = formatter.formatInfo("The publisher is: ", publisherName);
		System.out.println(info);
		info = formatter.formatInfo("The year is: ", String.valueOf(year));
		System.out.println(info);
	}

	/**
	 * @return the publisherName
	 */
	public String getPublisherName() {
		return publisherName;
	}

	/**
	 * @param publisherName
	 *            the publisherName to set
	 */
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

}
