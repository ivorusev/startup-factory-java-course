/**
 * 
 */
package org.sf.jc.designpatterns.factory;

/**
 * @author irusev
 *
 */
public abstract class Figure {
	
	protected int x;
	protected int y;
	
	abstract void draw();

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
