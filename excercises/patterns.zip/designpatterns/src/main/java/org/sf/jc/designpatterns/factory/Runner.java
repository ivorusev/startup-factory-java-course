/**
 * 
 */
package org.sf.jc.designpatterns.factory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Figure circle1 = FiguresFactory.createFigure(FigureIds.CIRCLE);
		Figure circle2 = FiguresFactory.createFigure(FigureIds.CIRCLE);
		Figure square = FiguresFactory.createFigure(FigureIds.SQUARE);
		List<Figure> figures = new ArrayList<>();
		figures.add(circle1);
		figures.add(circle2);
		figures.add(square);
		figures.forEach(figure -> figure.draw());
	}

}
