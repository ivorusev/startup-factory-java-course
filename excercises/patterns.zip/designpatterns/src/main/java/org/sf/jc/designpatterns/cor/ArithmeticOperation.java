/**
 * 
 */
package org.sf.jc.designpatterns.cor;

/**
 * @author irusev
 *
 */
public class ArithmeticOperation {
	
	private int firstNumber;
	private int secondNumber;
	private Operations operation;
	
	
	public int getFirstNumber() {
		return firstNumber;
	}


	public void setFirstNumber(int firstNumber) {
		this.firstNumber = firstNumber;
	}


	public int getSecondNumber() {
		return secondNumber;
	}


	public void setSecondNumber(int secondNumber) {
		this.secondNumber = secondNumber;
	}


	public Operations getOperation() {
		return operation;
	}


	public void setOperation(Operations operation) {
		this.operation = operation;
	}


	public ArithmeticOperation(int firstNumber, int secondNumber, Operations operation) {
		this.firstNumber = firstNumber;
		this.secondNumber = secondNumber;
		this.operation = operation;
	}
	

}
