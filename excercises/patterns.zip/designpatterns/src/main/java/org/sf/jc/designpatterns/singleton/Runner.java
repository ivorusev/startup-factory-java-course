/**
 * 
 */
package org.sf.jc.designpatterns.singleton;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (DBConnector.getInstance() != null) {
			System.out.println("Success!");
		}
		
	}

}
