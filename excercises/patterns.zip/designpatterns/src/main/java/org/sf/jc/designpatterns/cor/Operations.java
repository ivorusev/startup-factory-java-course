package org.sf.jc.designpatterns.cor;

public enum Operations {
    ADD, SUBSTRACT, MULTIPLY, DIVIDE;
}