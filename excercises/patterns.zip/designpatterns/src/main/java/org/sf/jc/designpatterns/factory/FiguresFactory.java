/**
 * 
 */
package org.sf.jc.designpatterns.factory;

/**
 * @author irusev
 *
 */
public class FiguresFactory {
	
	public static Figure createFigure(FigureIds id) {
		if (id == FigureIds.CIRCLE) {
			return new Circle(1, 1, 10);
		} else if (id == FigureIds.SQUARE) {
			return new Square(2, 2, 5);
		}
		return null;
	}

}
