package org.sf.jc.designpatterns.bridge;

public abstract class MyFormatter {

	public abstract String formatInfo(String string, String publisherName);

}
