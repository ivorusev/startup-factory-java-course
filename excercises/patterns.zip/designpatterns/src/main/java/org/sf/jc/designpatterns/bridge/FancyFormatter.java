package org.sf.jc.designpatterns.bridge;

public class FancyFormatter extends MyFormatter {

	@Override
	public String formatInfo(String userInformation, String value) {
		StringBuilder sb = new StringBuilder();
		sb.append(" * ").append(userInformation).append(" : [").append(value).append("]")
				.append(System.lineSeparator());
		return sb.toString();
	}

}
