package org.sf.jc.designpatterns.factory;

public enum FigureIds {
    CIRCLE, SQUARE; 
}