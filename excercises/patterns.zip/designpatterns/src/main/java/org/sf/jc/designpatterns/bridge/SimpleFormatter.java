/**
 * 
 */
package org.sf.jc.designpatterns.bridge;

/**
 * @author irusev
 *
 */
public class SimpleFormatter extends MyFormatter {

	/* (non-Javadoc)
	 * @see org.sf.jc.designpatterns.bridge.MyFormatter#formatInfo(java.lang.String, java.lang.String)
	 */
	@Override
	public String formatInfo(String string, String publisherName) {
		return "---------" + string + " = " + publisherName;
	}

}
