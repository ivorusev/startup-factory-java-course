package org.sf.jc.designpatterns.cor;

public abstract class ArithmeticChain {
	
	protected ArithmeticChain next;

	public void setNext(ArithmeticChain next) {
		this.next = next;
	}
	
	abstract void handle(ArithmeticOperation operation); 
	

}
