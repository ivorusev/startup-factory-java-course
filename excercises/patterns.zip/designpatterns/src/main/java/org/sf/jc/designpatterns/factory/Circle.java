package org.sf.jc.designpatterns.factory;

public class Circle extends Figure {

	private int radius;

	public Circle(int x, int y, int radius) {
		super.x = x;
		super.y = y;
		this.setRadius(radius);
	}

	@Override
	void draw() {
		System.out.println("Drawing a circle with radius =" + radius);
	}

	/**
	 * @return the radius
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * @param radius
	 *            the radius to set
	 */
	public void setRadius(int radius) {
		this.radius = radius;
	}

}
