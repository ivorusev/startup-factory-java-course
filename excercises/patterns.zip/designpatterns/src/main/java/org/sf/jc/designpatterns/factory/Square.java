/**
 * 
 */
package org.sf.jc.designpatterns.factory;

/**
 * @author irusev
 *
 */
public class Square extends Figure {

	private int side;

	public Square(int x, int y, int side) {
		super.x = x;
		super.y = y;
		this.setSide(side);
	}

	@Override
	void draw() {
		System.out.println("Drawing a square.");
	}

	/**
	 * @return the side
	 */
	public int getSide() {
		return side;
	}

	/**
	 * @param side the side to set
	 */
	public void setSide(int side) {
		this.side = side;
	}

}
