/**
 * 
 */
package org.sf.jc.designpatterns.bridge;

/**
 * @author irusev
 *
 */
public abstract class Manuscript {
	
	protected MyFormatter formatter;
	
	public Manuscript(MyFormatter formatter) {
		this.formatter = formatter;
	}
	
	abstract void printInformation();

}
