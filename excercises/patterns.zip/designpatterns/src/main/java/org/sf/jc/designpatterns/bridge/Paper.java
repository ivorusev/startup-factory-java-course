/**
 * 
 */
package org.sf.jc.designpatterns.bridge;

/**
 * @author irusev
 *
 */
public class Paper extends Manuscript {

	private int pages;

	public Paper(MyFormatter formatter) {
		super(formatter);
	}

	public Paper(MyFormatter formatter, int page) {
		super(formatter);
		this.pages = page;
	}

	@Override
	void printInformation() {
		String formatInfo = formatter.formatInfo("Pages are: ", String.valueOf(pages));
		System.out.println(formatInfo);
	}

}
