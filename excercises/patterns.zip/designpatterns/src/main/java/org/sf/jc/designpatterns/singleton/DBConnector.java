/**
 * 
 */
package org.sf.jc.designpatterns.singleton;

/**
 * @author irusev
 *
 */
public class DBConnector {
	
	private static DBConnector instance;
	
	private DBConnector() {
	}
	
	public static synchronized DBConnector getInstance() {
		if (instance == null) {
			instance = new DBConnector();
		}
		return instance;
	}

}
