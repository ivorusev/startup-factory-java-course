/**
 * 
 */
package org.sf.jc.designpatterns.cor;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArithmeticChain addition = new Addition();
		ArithmeticChain subs = new Substraction();
		ArithmeticChain multiply = new Multiplication();
		
		addition.setNext(subs);
		subs.setNext(multiply);
		
		ArithmeticOperation op = new ArithmeticOperation(20, 7, Operations.SUBSTRACT);
		
		//addition.handle(op);
		multiply.handle(op);
	}

}
