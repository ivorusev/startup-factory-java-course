package org.sf.jc.designpatterns.cor;

public class Substraction extends ArithmeticChain {

	protected ArithmeticChain next;
	
	@Override
	void handle(ArithmeticOperation operation) {
		if (operation.getOperation() == Operations.SUBSTRACT) {
			System.out.println(operation.getFirstNumber() - operation.getSecondNumber());
			return;
		}
		if (next != null) {
			next.handle(operation);
		}
		
	}

}
