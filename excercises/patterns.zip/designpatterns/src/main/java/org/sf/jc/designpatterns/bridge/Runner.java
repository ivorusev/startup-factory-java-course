package org.sf.jc.designpatterns.bridge;

public class Runner {

	public static void main(String[] args) {
		MyFormatter fancy = new FancyFormatter();
		MyFormatter simple = new SimpleFormatter();
		
		Manuscript book = new Book(simple, "O'Reiley", 2009);
		// book.printInformation();
		Manuscript paper = new Paper(simple, 12);
		paper.printInformation();
	}

}
