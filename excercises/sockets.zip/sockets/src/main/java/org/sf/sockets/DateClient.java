package org.sf.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateClient {

	private static final Logger LOG = LoggerFactory.getLogger(DateClient.class);

	public static void main(String[] args) {
		Socket socket = null;
		try {
			LOG.info("Client has started.");
			socket = new Socket("192.168.0.111", 8091);

			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String date = in.readLine();
			LOG.info("The current date is {} ", date);
		} catch (IOException e) {
			LOG.error("Could not connect", e);
		} finally {
			try {
				socket.close();
			} catch (IOException e1) {
				LOG.error("Could not close stream", e1);
			}
		}
	}

}
