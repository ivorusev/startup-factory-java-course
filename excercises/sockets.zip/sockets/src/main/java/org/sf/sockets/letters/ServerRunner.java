package org.sf.sockets.letters;

public class ServerRunner {

	public static void main(String[] args) {
		UpperCaseServer.getInstance().startServer();
	}

}
