package org.sf.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateServer {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateServer.class);

	public static void main(String[] args) {
		ServerSocket server = null;
		try {
			LOGGER.info("Date Server started!");
			server = new ServerSocket(8091);

			while (true) {
				Socket client = server.accept();
				LOGGER.info("Client [{}] has connected, going to send the current date",
						client.getRemoteSocketAddress());

				PrintWriter out = new PrintWriter(client.getOutputStream(), true);
				
				client.close();
				Thread.sleep(20000);
				
				Date now = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.YYYY");
				String dateAsString = formatter.format(now);
				out.println(dateAsString);
			}
		} catch (InterruptedException | IOException e) {
			LOGGER.error("IO error", e);
		} finally {
			try {
				server.close();
			} catch (IOException e) {
				LOGGER.error("Could not close socket: ", e);
			}
		}
	}

}
