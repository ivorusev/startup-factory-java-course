/**
 * 
 */
package org.sf.sockets.letters;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author irusev
 *
 */
public class UpperCaseServer {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpperCaseServer.class);

	private static UpperCaseServer server;

	private UpperCaseServer() {
	}

	public static synchronized UpperCaseServer getInstance() {
		if (server == null) {
			server = new UpperCaseServer();
		}
		return server;
	}

	public void startServer() {
		LOGGER.info("Server started.");
		try (ServerSocket server = new ServerSocket(8091)) {
			while (true) {
				Socket client = server.accept();
				LOGGER.info("Client [{}] has connected, going to send the current date",
						client.getRemoteSocketAddress());
				UpperCaseWroker worker = new UpperCaseWroker(client);
				Thread thread = new Thread(worker);
				thread.start();
			}
		} catch (IOException e) {
			LOGGER.error("Something unexpected happened!", e);
		}
	}
}
