package org.sf.sockets.letters;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LettersClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(LettersClient.class);

	public static void main(String[] args) throws UnknownHostException, IOException {
		Socket socket = new Socket("localhost", 8091);

		PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));

		Scanner console = new Scanner(System.in);
		String oneline = "";
		while (((oneline = console.nextLine()) != null) && (!oneline.equalsIgnoreCase("end"))) {
			out.println(oneline);
			String word = in.readLine();
			LOGGER.info("The server response is : {}", word);
		}
		
		socket.close();
		console.close();
	}

}
