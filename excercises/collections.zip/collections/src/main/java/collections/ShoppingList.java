/**
 * 
 */
package collections;

import java.util.ArrayList;
import java.util.List;

/**
 * @author irusev
 *
 */
public class ShoppingList {
	
	private static ShoppingList list = new ShoppingList();
	
	private List<Product> products = new ArrayList<Product>();
	
	private ShoppingList() {
	}
	
	public static ShoppingList getInstance() {
		return list;
	}
	
	public boolean isProductContained(Product product) {
		for (Product prod : products) {
			if (prod.compareTo(product) == 0) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return the products
	 */
	public List<Product> getProducts() {
		return products;
	}

	/**
	 * @param products the products to set
	 */
	public void setProducts(List<Product> products) {
		this.products = products;
	}

}
