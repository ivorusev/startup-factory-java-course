/**
 * 
 */
package collections;

import java.util.Collections;
import java.util.List;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Product milk = new Product("Milk", 1.89f, 2);
		Product vodka = new Product("Vodka", 23f, 1);
		Product juice = new Product("Orange Juice", 2, 7);
		
		ShoppingList.getInstance().getProducts().add(milk);
		ShoppingList.getInstance().getProducts().add(vodka);
		ShoppingList.getInstance().getProducts().add(juice);
		
		List<Product> products = ShoppingList.getInstance().getProducts();
		Collections.sort(products);
		
		//products.stream().forEach(System.out::println);
		products.stream().forEach(product-> {
			product.setPrice(product.getPrice() * 2);
			System.out.println(product.getPrice());
		});
		
		
		products.contains(milk);
	}

}
