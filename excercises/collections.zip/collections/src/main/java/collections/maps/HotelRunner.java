/**
 * 
 */
package collections.maps;

/**
 * @author irusev
 *
 */
public class HotelRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HotelService service = new HotelService();
		service.clean();
		// TODO Auto-generated method stub

	}

}
