/**
 * 
 */
package collections.maps;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author irusev
 *
 */
public class HotelService {

	Map<Integer, String> requests = new LinkedHashMap<>();

	public HotelService() {
		requests.put(1, "Ivan");
		requests.put(2, "Pesho");
		requests.put(3, "Toni");
	}

	public void clean() {
		Iterator<Integer> iterator = requests.keySet().iterator();
		while (iterator.hasNext()) {
			Integer next = iterator.next();
			System.out.println("Cleaning room: " + next + " for person: " + requests.get(next));
			iterator.remove();
		}
	}

}
