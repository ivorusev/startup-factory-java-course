/**
 * 
 */
package collections.maps;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Dictionary dictionary = new Dictionary();
		System.out.println(dictionary.translate("куче"));

	}

}
