/**
 * 
 */
package collections.maps;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author irusev
 *
 */
public class Dictionary {
	
	private Map<String, String> dictionary = new HashMap<>();
	
	public Dictionary() {
		dictionary.put("dog", "куче");
		dictionary.put("cat", "че");
		dictionary.put("rat", "е");
	}
	
	public String translate(String word) {
		if (word.matches("[a-zA-Z]{1,100}")) {
			return dictionary.get(word);
		} else {
			Iterator<String> iterator =  dictionary.keySet().iterator();
			while(iterator.hasNext()) {
				String nextKey = iterator.next();
				if (dictionary.get(nextKey).equals(word)) {
					return nextKey;
				}
			}
		}
		return null;
	}

}
