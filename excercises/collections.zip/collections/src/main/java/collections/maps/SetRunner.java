/**
 * 
 */
package collections.maps;

import java.util.HashSet;
import java.util.Set;

/**
 * @author irusev
 *
 */
public class SetRunner {
	
	public static void main(String[] args) {
		Set<String> setA = new HashSet<>();
		setA.add("A");
		setA.add("B");
		setA.add("C");
		Set<String> setB = new HashSet<>();
		setB.add("C");
		setB.add("D");
		setB.add("E");
		
		setA.removeAll(setB);
		System.out.println(setA);
		
	}

}
