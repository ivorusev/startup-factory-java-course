/**
 * 
 */
package collections;

/**
 * @author irusev
 *
 */
public class Product implements Comparable<Product> {

	private String name;
	private float price;
	private int quantity;

	public Product(String name, float price, int quantity) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public int compareTo(Product o) {
		return o.name.compareTo(this.name);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("The name of the product is: ").append(name).append(". Price: ").append(price)
				.append(". Quantity is: ").append(quantity);
		return sb.toString();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
