/**
 * 
 */
package threads;

/**
 * @author irusev
 *
 */
public class HelloWorldThread extends Thread {
	
	@Override
	public void run() {
		String threadName = Thread.currentThread().getName();
		System.out.println("Hello world from thread " + threadName);
	}

}
