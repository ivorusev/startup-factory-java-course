/**
 * 
 */
package threads.counter;

/**
 * @author irusev
 *
 */
public class Counter {
	
	private static int count = 0;
	
	public static synchronized void add() {
		count = count + 1;
	}
	
	public static int getCount() {
		return count;
	}
	
	

}
