/**
 * 
 */
package threads.counter;

/**
 * @author irusev
 *
 */
public class CounterWorker implements Runnable {

	private int maxlimit;

	public CounterWorker(int maxLimit) {
		this.maxlimit = maxLimit;
	}

	@Override
	public void run() {
		for (int i = 0; i < maxlimit; i++) {
			// System.out.println(Thread.currentThread().getName() + " increase the counter by 1.");
			Counter.add();
		}
	}

}
