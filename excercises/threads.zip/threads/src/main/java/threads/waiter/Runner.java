/**
 * 
 */
package threads.waiter;

import threads.counter.Counter;
import threads.counter.CounterWorker;

/**
 * @author irusev
 *
 */
public class Runner {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		WaitingThread waitingThread = new WaitingThread();
		Thread thread1 = new Thread(waitingThread);
		thread1.start();

		System.out.println(" >>> ");

		waitingThread.isRunning = false;
		while (true) {

		}
	}

}
