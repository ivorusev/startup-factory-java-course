package threads.waiter;

public class WaitingThread implements Runnable {

	public boolean isRunning = true;

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " is going for a nap.");
		try {
			synchronized (this) {
				this.wait();
			}
			System.out.println("Wake up");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
