package threads;

public class Runner {

	public static void main(String[] args) {
		HelloWorldRunnable myRunnable = new HelloWorldRunnable();
		Thread myRunnableThread = new Thread(myRunnable);
		
		Runnable myLambdaThread = () -> {
			String threadName = Thread.currentThread().getName();
			System.out.println("Hello world from lambda " + threadName);

		};

		HelloWorldThread myThread = new HelloWorldThread();

		myThread.start();
		myRunnableThread.start();
		new Thread(myLambdaThread).start();
	}

}
