package threads;

public class HelloWorldRunnable implements Runnable {

	public void run() {
		String threadName = Thread.currentThread().getName();
		System.out.println("Hello world from runnable " + threadName);
	}

}
