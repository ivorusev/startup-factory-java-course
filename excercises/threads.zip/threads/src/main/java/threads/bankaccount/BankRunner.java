/**
 * 
 */
package threads.bankaccount;

/**
 * @author irusev
 *
 */
public class BankRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BankAccount to = new BankAccount("1", 300);
		BankAccount from = new BankAccount("2", 5000);
		
		BankAccountWorker r1 = new BankAccountWorker(from, to, 10);
		BankAccountWorker r2 = new BankAccountWorker(to, from, 200);
		
		Thread t1 = new Thread(r1);
		t1.start();
		Thread t2 = new Thread(r2);
		t2.start();
		
		while (t1.isAlive() || t2.isAlive()) {
		}
		System.out.println(to.getBalance());
		System.out.println(from.getBalance());
	}

}
