/**
 * 
 */
package threads.bankaccount;

/**
 * @author irusev
 *
 */
public class BankAccountWorker implements Runnable {
	
	private BankAccount from;
	private BankAccount to;
	private int amount;

	public BankAccountWorker(BankAccount from, BankAccount to, int amount) {
		this.from = from;
		this.to = to;
		this.amount = amount;
	}

	@Override
	public void run() {
		from.transfer(to, amount);
	}

}
