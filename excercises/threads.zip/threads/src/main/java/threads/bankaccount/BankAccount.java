package threads.bankaccount;

public class BankAccount {

	private String id;

	private int balance;

	public BankAccount(String id, int balance) {
		this.id = id;
		this.balance = balance;
	}

	public void transfer(BankAccount to, int amount) {
		this.whithdraw(amount);
		to.deposit(amount);
	}

	public synchronized void deposit(int amount) {
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.balance += amount;

	}

	public synchronized void whithdraw(int amount) {
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.balance -= amount;
	}

	public String getId() {
		return id;
	}

	public int getBalance() {
		return balance;
	}

}
